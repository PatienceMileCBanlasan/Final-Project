// script.js

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("signupForm");
    if (form) {
      form.addEventListener("submit", function (e) {
        e.preventDefault();
        let valid = true;
  
        const firstName = document.getElementById("firstName").value.trim();
        const lastName = document.getElementById("lastName").value.trim();
        const sex = document.querySelector('input[name="sex"]:checked');
        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value.trim();
        const reason = document.getElementById("reason").value.trim();
  
        const setError = (id, message) => {
          document.getElementById(id).textContent = message;
        };
  
        setError("errorFirstName", firstName ? "" : "Required");
        setError("errorLastName", lastName ? "" : "Required");
        setError("errorSex", sex ? "" : "Required");
        setError("errorEmail", email ? "" : "Required");
        setError("errorPassword", password ? "" : "Required");
        setError("errorReason", reason ? "" : "Required");
  
        valid = firstName && lastName && sex && email && password && reason;
  
        if (valid) {
          localStorage.setItem("firstName", firstName);
          localStorage.setItem("lastName", lastName);
          localStorage.setItem("sex", sex.value);
          localStorage.setItem("email", email);
          localStorage.setItem("reason", reason);
          window.location.href = "proj_profile_Banlasan.html";
        }
      });
    }
  
    // Populate profile page
    if (document.getElementById("displayFirstName")) {
      document.getElementById("displayFirstName").textContent = localStorage.getItem("firstName");
      document.getElementById("displayLastName").textContent = localStorage.getItem("lastName");
      document.getElementById("displayEmail").textContent = localStorage.getItem("email");
      document.getElementById("displaySex").textContent = localStorage.getItem("sex");
      document.getElementById("displayReason").textContent = localStorage.getItem("reason");
    }
  });
  